import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBuddyComponent } from './my-buddy.component';

describe('MyBuddyComponent', () => {
  let component: MyBuddyComponent;
  let fixture: ComponentFixture<MyBuddyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyBuddyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBuddyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
