import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-buddy',
  templateUrl: './my-buddy.component.html',
  styleUrls: ['./my-buddy.component.css']
})
export class MyBuddyComponent implements OnInit
{
  names:string=""           //  Enter name in browser
  mail:string=""            // Enter mail in browser
  list1:string[]=[]
  list2:string[]=[]
  display(items:string,mail:string)
  {
    // Entered items are in template that is pushed on the list array
    this.list1.push(this.names)         // name of the buddy
    this.list2.push(this.mail)    // EmailID of the buddy
  }
  constructor() { }
  ngOnInit(): void {}
}