import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MyBuddyComponent } from './my-buddy/my-buddy.component';

@NgModule({
  declarations: [
    AppComponent,
    MyBuddyComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }