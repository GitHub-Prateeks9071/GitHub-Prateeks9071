let express = require('express')
let app = express()

app.get("/mybuddy", function(req, res){
	res.sendFile("q1.html", {root:__dirname})
})

app.get("/Add-Buddy", function(req, res) {
	let str = "<h3>My Buddy</h3><br>"
	str += "<p> Name : " + name +"<br> Email : " + email + "</p>"
	res.send(200, str, false)
})

app.listen(3000, "127.0.0.1", function(){
	console.log("Running...")
})
