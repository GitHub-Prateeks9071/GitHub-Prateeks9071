package Java_Exam;

public class Sphere
{
	public int rad;
	public Sphere() {}
	public Sphere(int rad)
	{
		this.rad = rad;
	}
	public void displayVolume() {}
	
	public void displaySurface() {}
	
}
