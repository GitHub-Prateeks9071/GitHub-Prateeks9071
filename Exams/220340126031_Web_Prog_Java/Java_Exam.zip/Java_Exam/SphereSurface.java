package Java_Exam;

public class SphereSurface extends Sphere
{
	public SphereSurface() {}
	
	public SphereSurface(int rad) 
	{
		super(rad);
	}
	public void displaySurface() 
	{
		double surface = 4 * Math.PI * super.rad * super.rad;
		System.out.println("The Surface Area of the Sphere is : " + String.format("%.2f", surface));
	}
}
