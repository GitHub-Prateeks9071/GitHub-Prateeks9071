package Java_Exam;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		int rad;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Radius : ");
		rad = sc.nextInt();
		Sphere vol = new SphereVolume(rad);
		vol.displayVolume();
		Sphere surface = new SphereSurface(rad);
		surface.displaySurface();
		sc.close();
	}
}
