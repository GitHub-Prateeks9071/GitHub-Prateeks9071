package Java_Exam;

public class SphereVolume extends Sphere
{
	public SphereVolume() {}
	
	public SphereVolume(int rad)
	{
		super(rad);
	}
	public void displayVolume()
	{
		double volume = 1.3333 * Math.PI * super.rad * super.rad * super.rad;
		System.out.println("The Volume of the Sphere is : " + String.format("%.2f", volume));
	}
}
